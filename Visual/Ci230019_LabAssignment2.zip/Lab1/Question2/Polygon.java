public interface Polygon {
    void setPerimeter();
    double getPerimeter();
    void setArea();
    double getArea();
}

